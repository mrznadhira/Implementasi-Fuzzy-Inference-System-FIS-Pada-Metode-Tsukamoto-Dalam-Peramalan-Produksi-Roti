<?php
    session_start();

    include "model.php";
?>

<!DOCTYPE html>

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title> Harum Bakery </title>
        <meta name="description" content="">
        
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/font-awesome.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/templatemo-style.css">
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
    </head>
    <body>

        <?php

        function selisih($aktual, $ramal){
            $hasil = $aktual - $ramal;
        return $hasil;
        }

        function pangkat($sel){
            $kali = $sel*$sel;
        return $kali;
         }

        function akar($jum){
            $hasil = $jum;
        return $hasil;
        }

        ?>
    
        <div class="responsive-header visible-xs visible-sm">
            <div class="container">
                
                <a href="#" class="toggle-menu"><i class="fa fa-bars"></i></a>
                <div class="main-navigation responsive-menu">
                    <ul class="navigation">
                        <li><a href="#top"><i class="fa fa-home"></i>Home</a></li>
                        <li><a href="#peramalan"><i class="fa fa-user"></i>Peramalan</a></li>
                        <li><a href="#pengujian"><i class="fa fa-envelope"></i>Hasil Pengujian</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- SIDEBAR -->
        <div class="sidebar-menu hidden-xs hidden-sm">
            
            <!-- top-section -->
            <div class="main-navigation">
                <ul class="navigation">
                    <li><a href="#top"><i class="fa fa-globe"></i>Home</a></li>
                    <li><a href="#peramalan"><i class="fa fa-user"></i>Peramalan</a></li>
                    <li><a href="#pengujian"><i class="fa fa-link"></i>Hasil Pengujian</a></li>
                </ul>
            </div> <!-- .main-navigation -->
            
        </div> <!-- .sidebar-menu -->
        

        <div class="banner-bg" id="top">
            <div class="banner-overlay"></div>
            <div class="welcome-text">
                <h2>Implementasi Fuzzy Inference System (FIS)
                <br>pada Metode Tsukamoto dalam Peramalan
                <br> Produksi Roti (Studi Kasus: Harum Bakery)</h2>
                <h5>Sistem ini digunakan untuk melakukan prediksi dalam proses produksi roti
                <br>pada Harum Bakery menggunakan Fuzzy Inference System pada Metode Tsukamoto</h5>
            </div>
        </div>

        <!-- MAIN CONTENT -->
        <div class="main-content">
            <div class="fluid-container">

                <div class="content-wrapper">
                
                    <!-- ABOUT -->
                    <div class="page-section" id="peramalan">
                    <div class="row">
                        <!-- <div class="col-md-12"> -->
                            <h4 class="widget-title"> Peramalan </h4>

                            <form name="hitung" action="result.php" method="POST">
                                <table>
                                    <tr>
                                        <td>( !! )ㅤSilahkan pilih lama bulan</td>
                                    </tr>
                                    <tr>
                                        <td>
                                        <br><select name="lama_bulan" onChange="top.location.href=this.options[this.selectedIndex].value;" value="GO">
                                            <option selected="selected">Pilih pengujian</option>
                                            <option value="20data.php"> 20 Data </option>
                                            <?php $_SESSION['data_20'] = "data_gabung"; ?>
                                            <option id="dua" value="40data.php"> 40 Data </option>
                                            <?php $_SESSION['data_40'] = "data_gabung40"; ?>
                                            <option id="tiga" value="60data.php"> 60 Data </option>
                                            <?php $_SESSION['data_60'] = "data_gabung60"; ?>
                                        </select>
                                        </td>
                                    </tr>                                                                         
                                
                            </table>
                            
                               <input type="submit" class="submit1" name="submit" value="submit">
                               
                        </form>
                        <hr>
                        <!-- </div> -->
                    </div> <!-- #peramalan -->
                    </div>
                    
                    <!-- Hasil pengujian -->
                    <div class="page-section" id="pengujian">
                    <div class="row">
                            <h4 class="widget-title">Hasil Pengujian</h4>
                            <!-- .projects-holder -->
                            <br>

                            Dari hasil peramalan yang dilakukan, maka dilakukan evaluasi sebagai berikut:

                            <h1 align="center" ><br><br><br><b> Hasil Evaluasi dengan 20 Data </b></h1>
                                <br><center><table  width="656" border="1" cellspacing="0" cellpadding="2">
                               
                                    <tr>
                                        <td> Data Aktual </td>
                                        <td> Roti manis </td>
                                        <td> Roti cake </td>
                                        <td> Roti tawar </td>
                                        <td> Data Peramalan </td>
                                        <td> Roti manis </td>
                                        <td> Roti cake </td>
                                        <td> Roti tawar </td>
                                    </tr>

                                    <?php
                                        include "koneksi.php";
                                        $sql = "SELECT * FROM eval_20";
                                        $result = mysqli_query($connect, $sql);
                                        while ($row = mysqli_fetch_array($result)) {
                                    ?>
                                    <tr><td></td>
                                        <td align="center"><?php echo $row['p_aktual_manis']; ?></td>
                                        <td align="center"><?php echo $row['p_aktual_cake']; ?></td>
                                        <td align="center"><?php echo $row['p_aktual_tawar']; ?></td>
                                        <td></td>
                                        <td align="center"><?php echo $row['p_ramal_manis']; ?></td>
                                        <td align="center"><?php echo $row['p_ramal_cake']; ?></td>
                                        <td align="center"><?php echo $row['p_ramal_tawar']; }?><br></td>
                                    </tr>
                                <br>
                                    </table></center>
                                    <tr><td> <br>Berdasarkan peramalan menggunakan 20 data, maka hasil evaluasi dengan RMSE adalah
                                        <br>
                                        <?php
                                        include "koneksi.php";
                                        $sql = "SELECT * FROM eval_20";
                                        $result = mysqli_query($connect, $sql);

                                        $jumManis = 0;
                                        $jumCake = 0;
                                        $jumTawar = 0;
                                        $jsManis = 0;
                                        $jsCake = 0;
                                        $jsTawar = 0;
                                        $coba_m = 0;
                                        $coba_c = 0;
                                        $coba_t = 0;

                                        while ($row = mysqli_fetch_array($result)) {

                                        $selManis = selisih($row['p_aktual_manis'], $row['p_ramal_manis']);
                                        $selCake = selisih($row['p_aktual_cake'], $row['p_ramal_cake']);
                                        $selTawar = selisih($row['p_aktual_tawar'], $row['p_ramal_tawar']);

                                        $pangManis = pangkat($selManis);
                                        $pangCake = pangkat($selCake);
                                        $pangTawar = pangkat($selTawar);

                                        $jsManis = $jsManis + $selManis;
                                        $jsCake = $jsCake + $selCake;
                                        $jsTawar = $jsTawar + $selTawar;

                                        $jumManis = $jumManis + $pangManis;
                                        $jumCake = $jumCake + $pangCake;
                                        $jumTawar = $jumTawar + $pangTawar;

                                        $coba_m = $coba_m + count($row['p_aktual_manis']);
                                        $coba_c = $coba_c + count($row['p_aktual_cake']);
                                        $coba_t = $coba_t + count($row['p_aktual_tawar']);

                                        $rManis = sqrt($jumManis/$coba_m);
                                        $rCake = sqrt($jumCake/$coba_c);
                                        $rTawar = sqrt($jumTawar/$coba_t);                                    
                                    }                                       

                                        echo "<br>Selisih roti manis : ".$jsManis;
                                        echo "<br>Selisih roti cake : ".$jsCake;
                                        echo "<br>Selisih roti tawar : ".$jsTawar;
                                        echo "<br><br>Jumlah pangkat roti manis : ".$jumManis;
                                        echo "<br>Jumlah pangkat roti cake : ".$jumCake;
                                        echo "<br>Jumlah pangkat roti tawar : ".$jumTawar;
                                        echo "<br><br>Hasil RMSE roti manis adalah: ".$rManis;
                                        echo "<br>Hasil RMSE roti cake adalah: ".$rCake;
                                        echo "<br>Hasil RMSE roti tawar adalah: ".$rTawar;
                                         ?>
                                     </td></tr>


                                    <h1 align="center" ><br><br><br><b> Hasil Evaluasi dengan 40 Data </b></h1>
                                <br>
                                <center><table  width="656" border="1" cellspacing="0" cellpadding="2">
                                
                                    <tr>
                                        <td> Data Aktual </td>
                                        <td> manis </td>
                                        <td> Roti cake </td>
                                        <td> Roti tawar </td>
                                        <td> Data Peramalan </td>
                                        <td> manis </td>
                                        <td> Roti cake </td>
                                        <td> Roti tawar </td>
                                    </tr>

                                     <?php
                                        include "koneksi.php";
                                        $sql = "SELECT * FROM eval_40";
                                        $result = mysqli_query($connect, $sql);
                                        while ($row = mysqli_fetch_array($result)) {
                                    ?>
                                    <tr><td></td>
                                        <td align="center"><?php echo $row['p_aktual_manis']; ?></td>
                                        <td align="center"><?php echo $row['p_aktual_cake']; ?></td>
                                        <td align="center"><?php echo $row['p_aktual_tawar']; ?></td>
                                        <td></td>
                                        <td align="center"><?php echo $row['p_ramal_manis']; ?></td>
                                        <td align="center"><?php echo $row['p_ramal_cake']; ?></td>
                                        <td align="center"><?php echo $row['p_ramal_tawar']; }?><br></td>
                                    </tr>
                                <br>
                                    </table></center>
                                    <tr><td> <br>Berdasarkan peramalan menggunakan 40 data, maka hasil evaluasi dengan RMSE adalah
                                        <br>
                                        <?php
                                        include "koneksi.php";
                                        $sql = "SELECT * FROM eval_40";
                                        $result = mysqli_query($connect, $sql);

                                        $jumManis = 0;
                                        $jumCake = 0;
                                        $jumTawar = 0;
                                        $jsManis = 0;
                                        $jsCake = 0;
                                        $jsTawar = 0;
                                        $coba_m = 0;
                                        $coba_c = 0;
                                        $coba_t = 0;

                                        while ($row = mysqli_fetch_array($result)) {

                                        $selManis = selisih($row['p_aktual_manis'], $row['p_ramal_manis']);
                                        $selCake = selisih($row['p_aktual_cake'], $row['p_ramal_cake']);
                                        $selTawar = selisih($row['p_aktual_tawar'], $row['p_ramal_tawar']);

                                        $pangManis = pangkat($selManis);
                                        $pangCake = pangkat($selCake);
                                        $pangTawar = pangkat($selTawar);

                                        $jsManis = $jsManis + $selManis;
                                        $jsCake = $jsCake + $selCake;
                                        $jsTawar = $jsTawar + $selTawar;

                                        $jumManis = $jumManis + $pangManis;
                                        $jumCake = $jumCake + $pangCake;
                                        $jumTawar = $jumTawar + $pangTawar;

                                        $coba_m = $coba_m + count($row['p_aktual_manis']);
                                        $coba_c = $coba_c + count($row['p_aktual_cake']);
                                        $coba_t = $coba_t + count($row['p_aktual_tawar']);

                                        $rManis = sqrt($jumManis/$coba_m);
                                        $rCake = sqrt($jumCake/$coba_c);
                                        $rTawar = sqrt($jumTawar/$coba_t);                                    
                                    }                                       

                                        echo "<br>Selisih roti manis : ".$jsManis;
                                        echo "<br>Selisih roti cake : ".$jsCake;
                                        echo "<br>Selisih roti tawar : ".$jsTawar;
                                        echo "<br><br>Jumlah pangkat roti manis : ".$jumManis;
                                        echo "<br>Jumlah pangkat roti cake : ".$jumCake;
                                        echo "<br>Jumlah pangkat roti tawar : ".$jumTawar;
                                        echo "<br><br>Hasil RMSE roti manis adalah: ".$rManis;
                                        echo "<br>Hasil RMSE roti cake adalah: ".$rCake;
                                        echo "<br>Hasil RMSE roti tawar adalah: ".$rTawar;
                                         ?>
                                     </td></tr>

                                    <h1 align="center" ><br><br><br><b> Hasil Evaluasi dengan 60 Data </b></h1>
                                <br>
                                <center><table  width="656" border="1" cellspacing="0" cellpadding="2">
                                
                                    <tr>
                                        <td> Data Aktual </td>
                                        <td> manis </td>
                                        <td> Roti cake </td>
                                        <td> Roti tawar </td>
                                        <td> Data Peramalan </td>
                                        <td> manis </td>
                                        <td> Roti cake </td>
                                        <td> Roti tawar </td>
                                    </tr>

                                     <?php
                                        include "koneksi.php";
                                        $sql = "SELECT * FROM eval_60";
                                        $result = mysqli_query($connect, $sql);
                                        while ($row = mysqli_fetch_array($result)) {
                                    ?>
                                    <tr><td></td>
                                        <td align="center"><?php echo $row['p_aktual_manis']; ?></td>
                                        <td align="center"><?php echo $row['p_aktual_cake']; ?></td>
                                        <td align="center"><?php echo $row['p_aktual_tawar']; ?></td>
                                        <td></td>
                                        <td align="center"><?php echo $row['p_ramal_manis']; ?></td>
                                        <td align="center"><?php echo $row['p_ramal_cake']; ?></td>
                                        <td align="center"><?php echo $row['p_ramal_tawar']; }?><br></td>
                                    </tr>
                                <br>
                                    </table></center>
                                    <tr><td> <br>Berdasarkan peramalan menggunakan 60 data, maka hasil evaluasi dengan RMSE adalah
                                        <br>
                                        <?php
                                        include "koneksi.php";
                                        $sql = "SELECT * FROM eval_60";
                                        $result = mysqli_query($connect, $sql);

                                        $jumManis = 0;
                                        $jumCake = 0;
                                        $jumTawar = 0;
                                        $jsManis = 0;
                                        $jsCake = 0;
                                        $jsTawar = 0;
                                        $coba_m = 0;
                                        $coba_c = 0;
                                        $coba_t = 0;

                                        while ($row = mysqli_fetch_array($result)) {

                                        $selManis = selisih($row['p_aktual_manis'], $row['p_ramal_manis']);
                                        $selCake = selisih($row['p_aktual_cake'], $row['p_ramal_cake']);
                                        $selTawar = selisih($row['p_aktual_tawar'], $row['p_ramal_tawar']);

                                        $pangManis = pangkat($selManis);
                                        $pangCake = pangkat($selCake);
                                        $pangTawar = pangkat($selTawar);

                                        $jsManis = $jsManis + $selManis;
                                        $jsCake = $jsCake + $selCake;
                                        $jsTawar = $jsTawar + $selTawar;

                                        $jumManis = $jumManis + $pangManis;
                                        $jumCake = $jumCake + $pangCake;
                                        $jumTawar = $jumTawar + $pangTawar;

                                        $coba_m = $coba_m + count($row['p_aktual_manis']);
                                        $coba_c = $coba_c + count($row['p_aktual_cake']);
                                        $coba_t = $coba_t + count($row['p_aktual_tawar']);

                                        $rManis = sqrt($jumManis/$coba_m);
                                        $rCake = sqrt($jumCake/$coba_c);
                                        $rTawar = sqrt($jumTawar/$coba_t);                                    
                                    }                                       

                                        echo "<br>Selisih roti manis : ".$jsManis;
                                        echo "<br>Selisih roti cake : ".$jsCake;
                                        echo "<br>Selisih roti tawar : ".$jsTawar;
                                        echo "<br><br>Jumlah pangkat roti manis : ".$jumManis;
                                        echo "<br>Jumlah pangkat roti cake : ".$jumCake;
                                        echo "<br>Jumlah pangkat roti tawar : ".$jumTawar;
                                        echo "<br><br>Hasil RMSE roti manis adalah: ".$rManis;
                                        echo "<br>Hasil RMSE roti cake adalah: ".$rCake;
                                        echo "<br>Hasil RMSE roti tawar adalah: ".$rTawar;
                                         ?>
                                     </td></tr>
                            
                        </div>
                    </div>
                     
                    </div>
                    <hr>
                </div>

            </div>
        </div>

        <script src="js/vendor/jquery-1.10.2.min.js"></script>
        <script src="js/min/plugins.min.js"></script>
        <script src="js/min/main.min.js"></script>

    </body>
</html>
