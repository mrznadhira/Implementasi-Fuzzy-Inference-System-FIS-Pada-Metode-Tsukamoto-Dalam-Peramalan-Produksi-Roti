<!DOCTYPE html>

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title> Harum Bakery </title>
        <meta name="description" content="">
        
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/font-awesome.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/templatemo-style.css">
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
    </head>
    <body>
    
        <div class="responsive-header visible-xs visible-sm">
            <div class="container">
                
                <a href="#" class="toggle-menu"><i class="fa fa-bars"></i></a>
                <div class="main-navigation responsive-menu">
                    <ul class="navigation">
                        <li><a href="#top"><i class="fa fa-home"></i>Home</a></li>
                        <li><a href="#peramalan"><i class="fa fa-user"></i>Peramalan</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- SIDEBAR -->
        <div class="sidebar-menu hidden-xs hidden-sm">
            
            <!-- top-section -->
            <div class="main-navigation">
                <ul class="navigation">
                    <li><a href="#top"><i class="fa fa-globe"></i>Home</a></li>
                    <li><a href="#peramalan"><i class="fa fa-user"></i>Peramalan</a></li>
                </ul>
            </div> <!-- .main-navigation -->
            
        </div> <!-- .sidebar-menu -->
        

        <div class="banner-bg" id="top">
            <div class="banner-overlay"></div>
            <div class="welcome-text">
                <h2>Implementasi Fuzzy Inference System (FIS)
                <br>pada Metode Tsukamoto dalam Peramalan
                <br> Produksi Roti (Studi Kasus: Harum Bakery)</h2>
                <h5>Sistem ini digunakan untuk melakukan peramalan dalam proses produksi roti
                <br>pada Harum Bakery menggunakan Fuzzy Inference System pada Metode Tsukamoto</h5>
            </div>
        </div>

        <!-- MAIN CONTENT -->
        <div class="main-content">
            <div class="fluid-container">

                <div class="content-wrapper">
                
                    <!-- ABOUT -->
                    <div class="page-section" id="peramalan">
                    <div class="row">
                        <!-- <div class="col-md-12"> -->
                            <h4 class="widget-title"> Peramalan </h4>

                                <p> Silakan mengisi data penjualan dan persediaan roti</p>

                            <form name="hitung" action="result.php" method="POST">
                                <table>
                                                                       
                                <tr class="tr1">
                                    <td><br><b> Input Penjualan, Persediaan dan Produksi </b></td>
                                    <?php
                                    session_start();
                                    $_SESSION['bulan'] = 'data_gabung';
                                    $_SESSION['jums'] = 20;
                                    ?>
                                    <tr><td>Pilih tanggal
                                        <?php include "koneksi.php";
                                        $sql = "SELECT * FROM ".$_SESSION['bulan']." limit 20,10";
                                        $result = mysqli_query($connect, $sql);
                                        echo "ㅤㅤ<select name='jum_data'>";
                                        while ($row = mysqli_fetch_array($result)) {
                                            echo "<option value='" . $row['no']."'>" .$row['tanggal']."</option>";
                                        }
                                        echo "</select>";
                                        ?></td>
                                    </tr>
                                </tr>
                            </table>
                            
                               <input type="submit" class="submit1" name="submit" value="submit">
                               
                        </form>
                        <hr>
                        <!-- </div> -->
                    </div> <!-- #peramalan -->
                    </div>
                    
                    <!-- Hasil pengujian -->
                    
                    </div>
                    <hr>
                </div>

            </div>
        </div>

        <script src="js/vendor/jquery-1.10.2.min.js"></script>
        <script src="js/min/plugins.min.js"></script>
        <script src="js/min/main.min.js"></script>

    </body>
</html>