<!DOCTYPE html>
<?php include 'model.php';

?> 
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title> Harum Bakery </title>
    <meta name="description" content="">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/font-awesome.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/templatemo-style.css">
    <script src="js/vendor/modernizr-2.6.2.min.js"></script>
</head>
<body>

    <div class="responsive-header visible-xs visible-sm">
        <div class="container">

            <a href="#" class="toggle-menu"><i class="fa fa-bars"></i></a>
            <div class="main-navigation responsive-menu">
                <ul class="navigation">
                    <li><a href="#peramalan"><i class="fa fa-user"></i>Peramalan</a></li>
                    <li><a href="#pengujian"><i class="fa fa-envelope"></i>Hasil Pengujian</a></li>
                </ul>
            </div>
        </div>
    </div>

    <!-- SIDEBAR -->
    <div class="sidebar-menu hidden-xs hidden-sm">

        <!-- top-section -->
        <div class="main-navigation">
            <ul class="navigation">
                <li><a href="#peramalan"><i class="fa fa-user"></i>Peramalan</a></li>
                <li><a href="#pengujian"><i class="fa fa-link"></i>Hasil Pengujian</a></li>
            </ul>
        </div> <!-- .main-navigation -->

    </div> <!-- .sidebar-menu -->




    <!-- MAIN CONTENT -->
    <div class="main-content">
        <div class="fluid-container">

            <div class="content-wrapper">

                <!-- ABOUT -->
                <div class="page-section" id="peramalan">
                    <div class="row">

                        <!-- <div class="col-md-12"> -->
                            <h4 class="widget-title"> Peramalan </h4>
                            <div class="row projects-holder">
                                <div class="col-md-4 col-sm-6">
                                    <div class="project-item">
                                        <img src="img/roti.jpg" alt="">
                                    </div>
                                </div>                      
                            </div> <!-- .projects-holder -->
                            <br><br><br>

                            <?php 
                            $manis_naik = 350;
                            $manis_turun = 3;
                            $manis_banyak = 180;
                            $manis_sedikit = 30;

                            $cake_naik = 35;
                            $cake_turun = 4;
                            $cake_banyak = 350;
                            $cake_sedikit = 50;


                            $tawar_naik = 30;
                            $tawar_turun = 4;
                            $tawar_banyak = 200;
                            $tawar_sedikit = 65;

                            $tambahPManis = 276;
                            $kurangPManis = 138;

                            $tambahPCake = 42;
                            $kurangPCake = 21;

                            $tambahPTawar = 24;
                            $kurangPTawar = 12;

                            include "koneksi.php";


                            $no = $_POST['jum_data'];

                            $bulan = array("data_gabung", "data_gabung40", "data_gabung60");
                            $jums = array(20,40,60);
                            session_start();

                            $tgl1 = mysqli_query($connect, "SELECT tanggal as tanggal FROM ".$_SESSION['bulan']." WHERE no = ".($no+1));
                            $tg1 = mysqli_fetch_array($tgl1);
                            $tanggal = $tg1['tanggal'];

                            echo "Tanggal pengujian: ".$tanggal;

                            $mns1 = mysqli_query($connect, "SELECT j_manis as j_manis FROM ".$_SESSION['bulan']." WHERE no = ".$no);
                            $mn1 = mysqli_fetch_array($mns1);
                            $manisJ = $mn1['j_manis'];

                            $ck1 = mysqli_query($connect,"SELECT j_cake as j_cake FROM ".$_SESSION['bulan']." where no = ".$no);
                            $ca1 = mysqli_fetch_array($ck1);
                            $cakeJ = $ca1['j_cake'];

                            $twr1 = mysqli_query($connect,"SELECT j_tawar as j_tawar FROM ".$_SESSION['bulan']." where no = ".$no);
                            $tw1 = mysqli_fetch_array($twr1);
                            $tawarJ = $tw1['j_tawar'];

                            $mns2 = mysqli_query($connect,"SELECT s_manis as s_manis FROM ".$_SESSION['bulan']." where no = ".$no);
                            $mn2 = mysqli_fetch_array($mns2);
                            $manisS = $mn2['s_manis'];

                            $ck2 = mysqli_query($connect,"SELECT s_cake as s_cake FROM ".$_SESSION['bulan']." where no = ".$no);
                            $ca2 = mysqli_fetch_array($ck2);
                            $cakeS = $ca2['s_cake'];

                            $twr2 = mysqli_query($connect,"SELECT s_tawar as s_tawar FROM ".$_SESSION['bulan']." where no = ".$no);
                            $tw2 = mysqli_fetch_array($twr2);
                            $tawarS = $tw2['s_tawar'];

                            $mns3 = mysqli_query($connect,"SELECT p_manis as p_manis FROM ".$_SESSION['bulan']." where no = ".($no+1));
                            $mn3 = mysqli_fetch_array($mns3);
                            $manisP = $mn3['p_manis'];

                            $ck3 = mysqli_query($connect,"SELECT p_cake as p_cake FROM ".$_SESSION['bulan']." where no = ".($no+1));
                            $ca3 = mysqli_fetch_array($ck3);
                            $cakeP = $ca3['p_cake'];

                            $twr3 = mysqli_query($connect,"SELECT p_tawar as p_tawar FROM ".$_SESSION['bulan']." where no = ".($no+1));
                            $tw3 = mysqli_fetch_array($twr3);
                            $tawarP = $tw3['p_tawar'];
                            

                            $h1 = array(); $h2 = array(); $h3 = array(); $h4 = array(); 

                            $i = 0;

                            $jum_data = data_latih($no,$_SESSION['jums']);
                            $f1=0;
                            while ($row = mysqli_fetch_array($jum_data)) {

                                //$f = count($row['j_manis']);                                    
                                //echo"uhuy".$f;

                                $j_tm = j_turun($row['j_manis'],$manis_naik,$manis_turun);
                                $j_nm = j_naik($row['j_manis'],$manis_naik,$manis_turun);
                                $s_sm = s_sedikit($row['s_manis'],$manis_sedikit,$manis_banyak);
                                $s_bm = s_banyak($row['s_manis'],$manis_sedikit,$manis_banyak);

                                $h1[$f1] = $j_tm; $h2[$f1] = $j_nm; $h3[$f1] = $s_sm; $h4[$f1] = $s_bm;                                  

                                $sedia1[$f1] = r_sedia($h3[$f1],$h4[$f1]); 
                                $jual1[$f1] = r_jual($h2[$f1],$h1[$f1]);

                                $f1 = $f1+1;
                            }

                            $a1 = j_turun($manisJ,$manis_naik,$manis_turun);
                            $b1 = j_naik($manisJ,$manis_naik,$manis_turun);
                            $c1 = s_sedikit($manisS,$manis_sedikit,$manis_banyak);
                            $d1 = s_banyak($manisS,$manis_sedikit,$manis_banyak);

                            $ap1 = array();
                            $z1 = array();
                            $az1 = array();
                            $produksi1 = array();

                            echo "<br><br><strong>rule roti manis didapatkan: </strong><br>";

                            global $ap1, $z1, $az1, $produksi1;

                            $i1 = 0;
                            $j1[0] = ''; $s1[0] = ''; $k1 = 0; $rule1[0] = '';
                            echo "<br>";
                            $counter1 = 0;
                            foreach ($jual1 as $jual1) {
                                if($i1 != 0){
                                    $tmp1 = $jual1.$sedia1[$i1];
                                    if(!(in_array($tmp1, $rule1))){
                                        $j1[$k1] = $jual1;
                                        $s1[$k1] = $sedia1[$i1];
                                        $rule1[$i1] = $tmp1;
                                        echo "Penjualan :".$j1[$k1]."  |  Persediaan :".$s1[$k1]."<br>";
                                        if($j1[$k1] == "turun" && $s1[$k1] == "sedikit"){
                                            $produksi1[$k1] = "Penjualan turun - Persediaan sedikit = Produksi berkurang";
                                            $ap1[$k1] = min($a1,$c1);
                                            $z1[$k1] = $tambahPManis - ($ap1[$k1] * ($tambahPManis - $kurangPManis));
                                        } elseif($j1[$k1] == "turun" && $s1[$k1] == "banyak"){
                                            $produksi1[$k1] = "Penjualan turun - Persediaan banyak = Produksi berkurang";
                                            $ap1[$k1] = min($a1,$d1);
                                            $z1[$k1] = $tambahPManis - ($ap1[$k1] * ($tambahPManis - $kurangPManis));
                                        } elseif($j1[$k1] == "naik" && $s1[$k1] == "sedikit"){
                                            $produksi1[$k1] = "Penjualan naik - Persediaan sedikit = Produksi bertambah";
                                            $ap1[$k1] = min($b1,$c1);
                                            $z1[$k1] = ($ap1[$k1] * ($tambahPManis - $kurangPManis)) + $kurangPManis;
                                        } elseif($j1[$k1] == "naik" && $s1[$k1] == "banyak"){
                                            $produksi1[$k1] = "Penjualan naik - Persediaan banyak = Produksi bertambah";
                                            $ap1[$k1] = min($b1,$d1);
                                            $z1[$k1] = ($ap1[$k1] * ($tambahPManis - $kurangPManis)) + $kurangPManis;
                                        } 
                                        $k1++;
                                        $counter1 +=1;
                                    }
                                }
                                $i1++;
                            }
                            echo "Jumlah rule: ".$counter1;

                            $tot_ap1 = 0; $tot_az1 = 0;

                            for ($i=0; $i < $counter1 ; $i++) { 

                                $az1[$i] = $ap1[$i] * $z1[$i];
                                $tot_ap1 += $ap1[$i];
                                $tot_az1 += $az1[$i];
                            }

                            $defuzz1 = $tot_az1 / $tot_ap1;        



                            $h5 = array(); $h6 = array(); $h7 = array(); $h8 = array(); $h9 = array(); $h10 = array();
                            $h11 = array(); $h12 = array();

                            $jum_data = data_latih($no,$_SESSION['jums']);
                            $f2=0;
                            while ($row = mysqli_fetch_array($jum_data)) {

                                $j_tc = j_turun($row['j_cake'],$cake_naik,$cake_turun);
                                $j_nc = j_naik($row['j_cake'],$cake_naik,$cake_turun);
                                $s_sc = s_sedikit($row['s_cake'],$cake_sedikit,$cake_banyak);
                                $s_bc = s_banyak($row['s_cake'],$cake_sedikit,$cake_banyak);
                                $j_tt = j_turun($row['j_tawar'],$tawar_naik,$tawar_turun);
                                $j_nt = j_naik($row['j_tawar'],$tawar_naik,$tawar_turun);
                                $s_st = s_sedikit($row['s_tawar'],$tawar_sedikit,$tawar_banyak);
                                $s_bt = s_banyak($row['s_tawar'],$tawar_sedikit,$tawar_banyak);
                                
                                $h5[$f2] = $j_tc; $h6[$f2] = $j_nc;  $h7[$f2] = $s_sc; $h8[$f2] = $s_bc; 
                                $h9[$f2] = $j_tt;  $h10[$f2] = $j_nt; $h11[$f2] = $s_st; $h12[$f2] = $s_bt;

                                $sedia2[$f2] = r_sedia($h7[$f2],$h8[$f2]); 
                                $jual2[$f2] = r_jual($h6[$f2],$h5[$f2]);

                                $f2 = $f2+1;
                            }

                            $a2 = j_turun($cakeJ,$cake_naik,$cake_turun);
                            $b2 = j_naik($cakeJ,$cake_naik,$cake_turun);
                            $c2 = s_sedikit($cakeS,$cake_sedikit,$cake_banyak);
                            $d2 = s_banyak($cakeS,$cake_sedikit,$cake_banyak);

                            $ap2 = array();
                            $z2 = array();
                            $az2 = array();
                            $produksi2 = array();

                            echo "<strong><br><br>rule roti cake didapatkan: </strong><br>";

                            global $ap2, $z2, $az2, $produksi2;

                            $i2 = 0;
                            $j2[0] = ''; $s2[0] = ''; $k2 = 0; $rule2[0] = '';
                            echo "<br>";
                            $counter2 = 0;
                            foreach ($jual2 as $jual2) {
                                if($i2 != 0){
                                    $tmp2 = $jual2.$sedia2[$i2];
                                    if(!(in_array($tmp2, $rule2))){
                                        $j2[$k2] = $jual2;
                                        $s2[$k2] = $sedia2[$i2];
                                        $rule2[$i2] = $tmp2;
                                        echo "Penjualan :".$j2[$k2]."  |  Persediaan :".$s2[$k2]."<br>";
                                        if($j2[$k2] == "turun" && $s2[$k2] == "sedikit"){
                                            $produksi2[$k2] = "Penjualan turun - Persediaan sedikit = Produksi berkurang";
                                            $ap2[$k2] = min($a2,$c2);
                                            $z2[$k2] = $tambahPCake - ($ap2[$k2] * ($tambahPCake - $kurangPCake));
                                        } elseif($j2[$k2] == "turun" && $s2[$k2] == "banyak"){
                                            $produksi2[$k2] = "Penjualan turun - Persediaan banyak = Produksi berkurang";
                                            $ap2[$k2] = min($a2,$d2);
                                            $z2[$k2] = $tambahPCake - ($ap2[$k2] * ($tambahPCake - $kurangPCake));
                                        } elseif($j2[$k2] == "naik" && $s2[$k2] == "sedikit"){
                                            $produksi2[$k2] = "Penjualan naik - Persediaan sedikit = Produksi bertambah";
                                            $ap2[$k2] = min($b2,$c2);
                                            $z2[$k2] = ($ap2[$k2] * ($tambahPCake - $kurangPCake)) + $kurangPCake;
                                        } elseif($j2[$k2] == "naik" && $s2[$k2] == "banyak"){
                                            $produksi2[$k2] = "Penjualan naik - Persediaan banyak = Produksi bertambah";
                                            $ap2[$k2] = min($b2,$d2);
                                            $z2[$k2] = ($ap2[$k2] * ($tambahPCake - $kurangPCake)) + $kurangPCake;
                                        } 
                                        $k2++;
                                        $counter2 +=1;
                                    }
                                }
                                $i2++;
                            }
                            echo "Jumlah rule: ".$counter2;

                            $tot_ap2 = 0; $tot_az2 = 0;

                            for ($i=0; $i < $counter2 ; $i++) { 

                                $az2[$i] = $ap2[$i] * $z2[$i];
                                $tot_ap2 += $ap2[$i];
                                $tot_az2 += $az2[$i];
                            }

                            $defuzz2 = $tot_az2 / $tot_ap2;      



                            $h9 = array(); $h10 = array(); $h11 = array(); $h12 = array();

                            $jum_data = data_latih($no,$_SESSION['jums']);
                            $f3=0;
                            while ($row = mysqli_fetch_array($jum_data)) {

                                $j_tt = j_turun($row['j_tawar'],$tawar_naik,$tawar_turun);
                                $j_nt = j_naik($row['j_tawar'],$tawar_naik,$tawar_turun);
                                $s_st = s_sedikit($row['s_tawar'],$tawar_sedikit,$tawar_banyak);
                                $s_bt = s_banyak($row['s_tawar'],$tawar_sedikit,$tawar_banyak);
                                
                                $h9[$f3] = $j_tt;  $h10[$f3] = $j_nt; $h11[$f3] = $s_st; $h12[$f3] = $s_bt;

                                $sedia3[$f3] = r_sedia($h11[$f3],$h12[$f3]); 
                                $jual3[$f3] = r_jual($h10[$f3],$h9[$f3]);

                                $f3 = $f3+1;
                            }

                            $a3 = j_turun($tawarJ,$tawar_naik,$tawar_turun);
                            $b3 = j_naik($tawarJ,$tawar_naik,$tawar_turun);
                            $c3 = s_sedikit($tawarS,$tawar_sedikit,$tawar_banyak);
                            $d3 = s_banyak($tawarS,$tawar_sedikit,$tawar_banyak);

                            $ap3 = array();
                            $z3 = array();
                            $az3 = array();
                            $produksi3 = array();

                            echo "<br><br><strong>rule roti tawar didapatkan: </strong><br>";

                            global $ap3, $z3, $az3, $produksi3;

                            $i3 = 0;
                            $j3[0] = ''; $s3[0] = ''; $k3 = 0; $rule3[0] = '';
                            echo "<br>";
                            $counter3 = 0;
                            foreach ($jual3 as $jual3) {
                                if($i3 != 0){
                                    $tmp3 = $jual3.$sedia3[$i3];
                                    if(!(in_array($tmp3, $rule3))){
                                        $j3[$k3] = $jual3;
                                        $s3[$k3] = $sedia3[$i3];
                                        $rule3[$i3] = $tmp3;
                                        echo "Penjualan :".$j3[$k3]."  |  Persediaan :".$s3[$k3]."<br>";
                                        if($j3[$k3] == "turun" && $s3[$k3] == "sedikit"){
                                            $produksi3[$k3] = "Penjualan turun - Persediaan sedikit = Produksi berkurang";
                                            $ap3[$k3] = min($a3,$c3);
                                            $z3[$k3] = $tambahPTawar - ($ap3[$k3] * ($tambahPTawar - $kurangPTawar));
                                        } elseif($j3[$k3] == "turun" && $s3[$k3] == "banyak"){
                                            $produksi3[$k3] = "Penjualan turun - Persediaan banyak = Produksi berkurang";
                                            $ap3[$k3] = min($a3,$d3);
                                            $z3[$k3] = $tambahPTawar - ($ap3[$k3] * ($tambahPTawar - $kurangPTawar));
                                        } elseif($j3[$k3] == "naik" && $s3[$k3] == "sedikit"){
                                            $produksi3[$k3] = "Penjualan naik - Persediaan sedikit = Produksi bertambah";
                                            $ap3[$k3] = min($b3,$c3);
                                            $z3[$k3] = ($ap3[$k3] * ($tambahPTawar - $kurangPTawar)) + $kurangPTawar;
                                        } elseif($j3[$k3] == "naik" && $s3[$k3] == "banyak"){
                                            $produksi3[$k3] = "Penjualan naik - Persediaan banyak = Produksi bertambah";
                                            $ap3[$k3] = min($b3,$d3);
                                            $z3[$k3] = ($ap3[$k3] * ($tambahPTawar - $kurangPTawar)) + $kurangPTawar;
                                        } 
                                        $k3++;
                                        $counter3 +=1;
                                    }
                                }
                                $i3++;
                            }
                            echo "Jumlah rule: ".$counter3;

                            $tot_ap3 = 0; $tot_az3 = 0;

                            for ($i3=0; $i3 < $counter3 ; $i3++) { 

                                $az3[$i3] = $ap3[$i3] * $z3[$i3];
                                $tot_ap3 += $ap3[$i3];
                                $tot_az3 += $az3[$i3];
                            }

                            $defuzz3 = $tot_az3 / $tot_ap3;          

                            

                            ?>

                            <br><br><br>
                            <strong><p> Hasil Fuzzyfikasi Roti Manis</p></strong><br>

                            <tr>
                                <td>ㅤㅤㅤTanggal</td>
                                <td> ㅤㅤㅤㅤㅤㅤㅤㅤㅤPenjualanㅤㅤㅤㅤㅤㅤㅤㅤ </td>
                                <td></td>           
                                <td> ㅤㅤㅤㅤㅤㅤㅤㅤㅤPersediaanㅤㅤㅤㅤ </td>
                                <td></td>                               
                            </tr>

                            <tr>
                                <td align="center"><br>ㅤ ㅤㅤㅤㅤㅤㅤㅤ</td>
                                <td align="center">ㅤㅤㅤㅤ Turunㅤ ㅤㅤㅤㅤㅤㅤㅤㅤ</td>           
                                <td align="center"> Naikㅤ ㅤㅤㅤㅤㅤㅤㅤ</td>
                                <td align="center"> Sedikitㅤㅤㅤㅤㅤㅤㅤㅤ </td>
                                <td align="center"> Banyakㅤㅤㅤㅤㅤㅤㅤㅤ </td>                                
                            </tr>

                            <tr><td></td>


                                <?php
                                $j = 0;
                                $jum_data = data_latih($no,$_SESSION['jums']);
                                while ($row = mysqli_fetch_array($jum_data)) {

                                    //$j = count($row['j_manis']);
                                    ?>
                                    <tr>
                                        <td align="center"><?php echo "<br>ㅤ|ㅤ ".$row['tanggal']; ?></td>
                                        <td align="center"><?php echo "ㅤ|ㅤ ".$h1[$j]; ?></td>        
                                        <td align="center"><?php echo "ㅤ|ㅤ ".$h2[$j]; ?></td>
                                        <td align="center"><?php echo "ㅤ|ㅤ ".$h3[$j]; ?></td>
                                        <td align="center"><?php echo "ㅤ|ㅤ".$h4[$j];  $j = $j+1;
                                    } ?></td></tr>

                                    <br><br><br>

                                    <strong><p> Hasil Fuzzyfikasi Roti Cake</p></strong>
                                    <br>
                                    <tr>
                                        <td>ㅤㅤㅤTanggal</td>
                                        <td> ㅤㅤㅤㅤㅤㅤㅤㅤㅤPenjualanㅤㅤㅤㅤㅤㅤㅤㅤ </td>
                                        <td></td>           
                                        <td> ㅤㅤㅤㅤㅤㅤㅤㅤㅤPersediaanㅤㅤㅤㅤ </td>
                                        <td></td>                                
                                    </tr>

                                    <tr>
                                        <td align="center"><br>ㅤ ㅤㅤㅤㅤㅤㅤㅤ</td>
                                        <td align="center">ㅤㅤㅤㅤ Turunㅤ ㅤㅤㅤㅤㅤㅤㅤ</td>           
                                        <td align="center"> Naikㅤ ㅤㅤㅤㅤㅤㅤㅤ</td>
                                        <td align="center"> Sedikitㅤㅤㅤㅤㅤㅤㅤㅤ </td>
                                        <td align="center"> Banyakㅤㅤㅤㅤㅤㅤㅤㅤ </td>                                
                                    </tr>

                                    <tr><td></td>

                                        <?php
                                        $j2 = 0;
                                        $jum_data = data_latih($no,$_SESSION['jums']);
                                        while ($row = mysqli_fetch_array($jum_data)) {
                                            ?>
                                            <tr>
                                                <td align="center"><?php echo "<br>ㅤ|ㅤ ".$row['tanggal']; ?></td>
                                                <td align="center"><?php echo "ㅤ|ㅤ ".$h5[$j2]; ?></td>           
                                                <td align="center"><?php echo "ㅤ|ㅤ ".$h6[$j2]; ?></td>
                                                <td align="center"><?php echo "ㅤ|ㅤ ".$h7[$j2]; ?></td>
                                                <td align="center"><?php echo "ㅤ|ㅤ".$h8[$j2];  $j2 = $j2+1;
                                            } ?></td></tr>

                                            <br><br><br>

                                            <strong><p> Hasil Fuzzyfikasi Roti Tawar</p></strong><br>

                                            <tr>
                                                <td>ㅤㅤㅤTanggal</td>
                                                <td> ㅤㅤㅤㅤㅤㅤㅤㅤㅤPenjualanㅤㅤㅤㅤㅤㅤㅤㅤ </td>
                                                <td></td>           
                                                <td> ㅤㅤㅤㅤㅤㅤㅤㅤㅤPersediaanㅤㅤㅤㅤ </td>
                                                <td></td>                               
                                            </tr>

                                            <tr>
                                                <td align="center"><br>ㅤ ㅤㅤㅤㅤㅤㅤㅤ</td>
                                                <td align="center">ㅤㅤㅤㅤ Turunㅤ ㅤㅤㅤㅤㅤㅤㅤ</td>           
                                                <td align="center"> Naikㅤ ㅤㅤㅤㅤㅤㅤㅤ</td>
                                                <td align="center"> Sedikitㅤㅤㅤㅤㅤㅤㅤㅤ </td>
                                                <td align="center"> Banyakㅤㅤㅤㅤㅤㅤㅤㅤ </td>                                
                                            </tr>
                                            <tr><td></td>


                                                <?php
                                                $j3 = 0;
                                                $jum_data = data_latih($no,$_SESSION['jums']);
                                                while ($row = mysqli_fetch_array($jum_data)) {

                                    //$j = count($row['j_manis']);
                                                    ?>
                                                    <tr>
                                                        <td align="center"><?php echo "<br>ㅤ|ㅤ ".$row['tanggal']; ?></td>
                                                        <td align="center"><?php echo "ㅤ|ㅤ ".$h9[$j3]; ?></td>
                                                        <td align="center"><?php echo "ㅤ|ㅤ ".$h10[$j3]; ?></td>
                                                        <td align="center"><?php echo "ㅤ|ㅤ ".$h11[$j3]; ?></td>
                                                        <td align="center"><?php echo "ㅤ|ㅤ".$h12[$j3];  $j3 = $j3+1;
                                                    } ?></td></tr>


                                                    <br><br><br>


                                                    <strong><p> DATA INPUT </p></strong>

                                                    <?php
                                                    echo "<br>Roti Manis = ".$manisJ." , Roti Cake = ".$cakeJ." , Roti Tawar = ".$tawarJ."<br>";

                                                    echo "<p>dan persediaan =</p>";

                                                    echo "<br>Roti Manis = ".$manisS." , Roti Cake = ".$cakeS." , Roti Tawar = ".$tawarS; 

                                                    ?>

                                                    <table class="alt">
                                                        <tbody><br><br>
                                                            <tr align="center">
                                                                <h1><b> Roti Manis </b></h1>
                                                                <br><td align="center"><b> Rule </b></td>
                                                                <td align="center"><b> ㅤㅤNilai α Roti Manis </b></td>
                                                                <td align="center"><b> ㅤㅤNilai z Roti Manis </b></td>
                                                            </tr>
                                                            <?php for ($l1=0; $l1 < $counter1; $l1++) {?>
                                                                <tr>                               
                                                                    <td align="center"> Rule <?php echo ($l1 + 1)." : " ?><?php echo $produksi1[$l1];?> </td>
                                                                    <td align="center"> ㅤㅤ<?php echo $ap1[$l1];?> </td>
                                                                    <td align="center"> ㅤㅤ<?php echo $z1[$l1]; }?> </td>
                                                                </tr>
                                                            </tbody>
                                                            <tfoot>
                                                                <tr><td colspan="2"><br> Rekomendasi jumlah produksi roti manis sebanyak : 
                                                                   <?php echo round("$defuzz1") ?></td>
                                                               </tr>
                                                               <tr>
                                                                <td colspan="2"><br> Data pakar produksi roti manis sebanyak :  
                                                                    <?php echo $manisP ?>
                                                                </td>
                                                            </tr>
                                                        </tfoot>
                                                    </table>

                                                    <table class="alt">
                                                        <tbody><br><br>
                                                            <tr align="center">
                                                                <h1><b> Roti Cake </b></h1>
                                                                <br><td align="center"><b> Rule </b></td>
                                                                <td align="center"><b> ㅤㅤNilai α Roti Cake </b></td>
                                                                <td align="center"><b> ㅤㅤNilai z Roti Cake </b></td>
                                                            </tr>
                                                            <?php for ($l1=0; $l1 < $counter2; $l1++) {?>
                                                                <tr>                               
                                                                    <td align="center"> Rule <?php echo ($l1 + 1)." : " ?><?php echo $produksi2[$l1];?> </td>
                                                                    <td align="center"> ㅤㅤ<?php echo $ap2[$l1];?> </td>
                                                                    <td align="center"> ㅤㅤ<?php echo $z2[$l1]; }?> </td>
                                                                </tr>
                                                            </tbody>
                                                            <tfoot>
                                                                <tr><td colspan="2"><br> Rekomendasi jumlah produksi roti cake sebanyak : 
                                                                   <?php echo round("$defuzz2") ?></td>
                                                               </tr>
                                                               <tr>
                                                                <td colspan="2"><br> Data pakar produksi roti cake sebanyak :  
                                                                    <?php echo $cakeP ?>
                                                                </td>
                                                            </tr>
                                                        </tfoot>
                                                    </table>

                                                    <table class="alt">
                                                        <tbody><br><br>
                                                            <tr align="center">
                                                                <h1><b> Roti Tawar </b></h1>
                                                                <br><td align="center"><b> Rule </b></td>
                                                                <td align="center"><b> ㅤㅤNilai α Roti Tawar </b></td>
                                                                <td align="center"><b> ㅤㅤNilai z Roti Tawar </b></td>
                                                            </tr>
                                                            <?php for ($l1=0; $l1 < $counter3; $l1++) {?>
                                                                <tr>                               
                                                                    <td align="center"> Rule <?php echo ($l1 + 1)." : " ?><?php echo $produksi3[$l1];?> </td>
                                                                    <td align="center"> ㅤㅤ<?php echo $ap3[$l1];?> </td>
                                                                    <td align="center"> ㅤㅤ<?php echo $z3[$l1]; }?> </td>
                                                                </tr>
                                                            </tbody>
                                                            <tfoot>
                                                                <tr><td colspan="2"><br> Rekomendasi jumlah produksi roti tawar sebanyak : 
                                                                   <?php echo round("$defuzz3") ?></td>
                                                               </tr>
                                                               <tr>
                                                                <td colspan="2"><br> Data pakar produksi roti tawar sebanyak :  
                                                                    <?php echo $tawarP ?>
                                                                </td>
                                                            </tr>
                                                        </tfoot>
                                                    </table>


                                                    <br><br><br>
                                                    <!-- </div> -->
                                                </div> <!-- #peramalan -->
                                            </div>

                                            <!-- Hasil pengujian -->
                                            <div class="page-section" id="pengujian">
                                                <div class="row">
                                                    <h4 class="widget-title">Hasil Pengujian</h4>
                                                    <!-- .projects-holder -->

                                                    <form name="hitung" action="simpan3.php" method="POST">
                                                        <table>

                                                            <tr class="tr1">
                                                                <td><br><b> Data Produksi Aktual </b></td>

                                                                <tr>
                                                                    <td>Roti Manisㅤ</td>
                                                                    <td>Roti Cakeㅤ</td>
                                                                    <td>Roti Tawar</td>
                                                                </tr>
                                                                <tr>
                                                                    <td><input type="text" name="m1" id="m1" value="<?php echo $manisP; ?>">ㅤ</td>
                                                                    <td><input type="text" name="c1" id="c1" value="<?php echo $cakeP; ?>">ㅤ</td>
                                                                    <td><input type="text" name="t1" id="t1" value="<?php echo $tawarP; ?>"></td>
                                                                </tr>
                                                                <tr class="tr1">
                                                                    <td><br><b> Data Produksi Peramalan </b></td>

                                                                    <tr><td>Roti Manisㅤ</td>
                                                                        <td>Roti Cakeㅤ</td>
                                                                        <td>Roti Tawar</td>
                                                                    </tr>

                                                                    <tr>
                                                                        <td><input type="text" name="m2" id="m2" value="<?php echo round("$defuzz1"); ?>">ㅤ</td>
                                                                        <td><input type="text" name="c2" id="c2" value="<?php echo round("$defuzz2"); ?>">ㅤ</td>
                                                                        <td><input type="text" name="t2" id="t2" value="<?php echo round("$defuzz3"); ?>"></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td><br><br><input type="submit" class="submit1" name="submitcoba2" value="submit"></td>
                                                                    </tr>
                                                                </table>
                                                            </form>

                                                        </div>
                                                    </div>



                                                    <hr>
                                                </div>

                                            </div>
                                        </div>

                                        <script src="js/vendor/jquery-1.10.2.min.js"></script>
                                        <script src="js/min/plugins.min.js"></script>
                                        <script src="js/min/main.min.js"></script>

                                    </body>
                                    </html>