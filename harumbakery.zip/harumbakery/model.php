<!DOCTYPE html>
<?php
function cari_bulan($bulan){
    if($bulan == "data_gabung"){
        $data = "data_20";
    } elseif($bulan == "data_gabung40"){
        $data = "data_40";
    } elseif($bulan == "data_gabung60"){
        $data = "data_60";
    }
    return $data;
}


function j_turun($x,$naik,$turun){
    if ($x <= $turun) {
        $hasil = '1';
    } else if($turun <= $x && $x <= $naik){
        $hasil = ($naik - $x)/($naik - $turun);
    } else if ($x >= $naik) {
        $hasil = '0';
    }
    return $hasil;
}

function j_naik($x,$naik,$turun){
    if ($x <= $turun) {
        $hasil = '0';
    } else if($turun <= $x && $x <= $naik){
        $hasil = ($x - $turun)/($naik - $turun);
    } else if ($x >= $naik) {
        $hasil = '1';
    }
    return $hasil;
} 

function s_sedikit($x,$sedikit,$banyak){
    if ($x <= $sedikit) {
        $hasil = '1';
    } else if($sedikit <= $x && $x<=$banyak){
        $hasil = ($banyak-$x)/($banyak-$sedikit);
    } else if ($x >= $banyak) {
        $hasil = '0';
    }
    return $hasil;
}

function s_banyak($x,$sedikit,$banyak){
    if ($x <= $sedikit) {
        $hasil = '0';
    } else if($sedikit <= $x && $x <= $banyak){
        $hasil = ($x-$sedikit)/($banyak-$sedikit);
    } else if ($x >= $banyak) {
        $hasil = '1';
    }
    return $hasil;
}

function p_berkurang($x,$kurang,$tambah){
    if ($x <= $kurang) {
        $hasil = '1';
    } else if($kurang <= $x && $x<=$tambah){
        $hasil = ($tambah - $x)/($tambah - $kurang);
    } else if ($x >= $tambah) {
        $hasil = '0';
    }
    return $hasil;
}

function p_bertambah($x,$kurang,$tambah){
    if ($x <= $kurang) {
        $hasil = '0';
    } else if($kurang <= $x && $x <= $tambah){
        $hasil = ($x - $kurang)/($tambah - $kurang);
    } else if ($x >= $tambah) {
        $hasil = '1';
    }
    return $hasil;
}

function r_jual($naik,$turun){

    if($naik > $turun){
        $r_jual = "naik";
    } else {
        $r_jual = "turun";
    }    
    return $r_jual;
}

function r_sedia($sedikit,$banyak){

    if($sedikit > $banyak){
        $r_sedia ="sedikit";
    } else {
        $r_sedia = "banyak";
    }
    return $r_sedia;
}

function seleksi($r_jual,$r_sedia,$produksi){
    $i = 0;
    $j[0] = ''; $s[0] = '';$p[0] = ''; $k = 0; $rule[0] = '';
    echo "<br>";
    foreach ($r_jual as $r_jual) {
     if($i != 0){
        $tmp = $r_jual.$r_sedia[$i].$produksi[$i];
        if(!(in_array($tmp, $rule))){
            $j[$k] = $r_jual;
            $s[$k] = $r_sedia[$i];
            $p[$k] = $produksi[$i];
            $rule[$i] = $tmp;
            echo "j :".$j[$k]." s :".$s[$k]." p :".$p[$k]." ".($i+1)."<br>";
            $k++;
        }
    }
    $i++;
}
}

function data_latih($t_pilih,$lama){
    include "koneksi.php";
    if($t_pilih>$lama){
        $t_awal = $t_pilih - $lama - 1;
        $sql = "select * from ".$_SESSION['bulan']." limit ".$t_awal.",".$lama;
        $result = mysqli_query($connect,$sql);
    }
    return $result;
}        

?>

</html>