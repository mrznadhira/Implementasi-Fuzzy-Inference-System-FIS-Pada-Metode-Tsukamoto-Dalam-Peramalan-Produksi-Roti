 <?php  
 session_start();

 $bulan = array("data_gabung", "data_gabung40", "data_gabung60");

 include "koneksi.php";

 if(isset($_POST['submitcoba2'])){
    if($_SESSION['bulan'] == 'data_gabung'){
        $query = "INSERT INTO eval_20(p_aktual_manis, p_aktual_cake, p_aktual_tawar, p_ramal_manis, p_ramal_cake, p_ramal_tawar) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($connect, $query) or die(mysqli_error($dbh));
        $stmt->bind_param('iiiiii', $m1, $c1, $t1, $m2, $c2, $t2 );

        $m1 = $_POST['m1'];
        $c1 = $_POST['c1'];
        $t1 = $_POST['t1'];
        $m2 = $_POST['m2'];
        $c2 = $_POST['c2'];
        $t2 = $_POST['t2'];


        $stmt->execute();
        $stmt->close();
        header("location: index.php");
    }
    elseif($_SESSION['bulan'] == 'data_gabung40'){

        $query = "INSERT INTO eval_40(p_aktual_manis, p_aktual_cake, p_aktual_tawar, p_ramal_manis, p_ramal_cake, p_ramal_tawar) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($connect, $query) or die(mysqli_error($dbh));
        $stmt->bind_param('iiiiii', $m1, $c1, $t1, $m2, $c2, $t2 );

        $m1 = $_POST['m1'];
        $c1 = $_POST['c1'];
        $t1 = $_POST['t1'];
        $m2 = $_POST['m2'];
        $c2 = $_POST['c2'];
        $t2 = $_POST['t2'];


        $stmt->execute();
        $stmt->close();
        header("location: index.php");

    } elseif($_SESSION['bulan'] == 'data_gabung60'){

        $query = "INSERT INTO eval_60(p_aktual_manis, p_aktual_cake, p_aktual_tawar, p_ramal_manis, p_ramal_cake, p_ramal_tawar) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($connect, $query) or die(mysqli_error($dbh));
        $stmt->bind_param('iiiiii', $m1, $c1, $t1, $m2, $c2, $t2 );

        $m1 = $_POST['m1'];
        $c1 = $_POST['c1'];
        $t1 = $_POST['t1'];
        $m2 = $_POST['m2'];
        $c2 = $_POST['c2'];
        $t2 = $_POST['t2'];


        $stmt->execute();
        $stmt->close();
        header("location: index.php");

    }
} 
?> <!--tutup php--->